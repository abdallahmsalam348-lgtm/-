package com.abdullah.salaty

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.content.Context
import android.location.LocationListener
import android.os.Looper
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 27, 23)
    private val panel = Color.rgb(14, 46, 38)
    private val gold = Color.rgb(216, 181, 109)
    private val white = Color.rgb(245, 242, 232)
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var nextPrayer: TextView
    private lateinit var timesBox: LinearLayout
    private val prayers = listOf("الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء")
    private val keys = listOf("Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha")
    private var timings: JSONObject? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestLocationAndLoad()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "صَلَاتِي"
            textSize = 30f
            setTextColor(gold)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "مواقيت الصلاة • على وقتها"
            textSize = 14f
            setTextColor(white)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "جارٍ تحديد موقعك..."
            textSize = 14f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 20)
        }
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(18, 22, 18, 22)
            setBackgroundColor(panel)
        }
        hero.addView(TextView(this).apply {
            text = "الصلاة القادمة"
            textSize = 15f
            setTextColor(white)
        })
        nextPrayer = TextView(this).apply {
            text = "—"
            textSize = 28f
            setTextColor(gold)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 4)
        }
        hero.addView(nextPrayer)
        hero.addView(TextView(this).apply {
            text = "سيتم حساب الوقت المتبقي بعد تحميل المواقيت"
            textSize = 12f
            setTextColor(white)
        })
        val heading = TextView(this).apply {
            text = "مواقيت اليوم"
            textSize = 20f
            setTextColor(gold)
            setPadding(0, 22, 0, 12)
        }
        timesBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 8, 14, 8)
            setBackgroundColor(panel)
        }
        val refresh = Button(this).apply {
            text = "تحديث المواقيت"
            setTextColor(bg)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(gold))
            setOnClickListener { requestLocationAndLoad() }
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(hero)
        root.addView(heading)
        root.addView(timesBox, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(refresh)
        setContentView(root)
        showPlaceholder()
    }

    private fun showPlaceholder() {
        timesBox.removeAllViews()
        prayers.forEach { name ->
            timesBox.addView(TextView(this).apply {
                text = "$name                                      --:--"
                textSize = 17f
                setTextColor(white)
                setPadding(8, 12, 8, 12)
            })
        }
    }

    private fun requestLocationAndLoad() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 22)
            status.text = "اسمح للتطبيق بالوصول للموقع لحساب المواقيت بدقة"
            return
        }
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (loc != null) loadTimings(loc.latitude, loc.longitude)
            else {
                status.text = "لم نتمكن من قراءة الموقع. فعّل GPS وحاول مرة أخرى."
                val listener = object : LocationListener {
                    override fun onLocationChanged(location: Location) {
                        loadTimings(location.latitude, location.longitude)
                        lm.removeUpdates(this)
                    }
                }
                lm.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, listener, Looper.getMainLooper())
            }
        } catch (e: Exception) {
            status.text = "تعذر تحديد الموقع: ${e.localizedMessage ?: "حاول مرة أخرى"}"
        }
    }

    private fun loadTimings(lat: Double, lon: Double) {
        runOnUiThread { status.text = "جارٍ جلب مواقيت الصلاة..." }
        executor.execute {
            try {
                val date = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date())
                val url = URL("https://api.aladhan.com/v1/timings/$date?latitude=$lat&longitude=$lon&method=5")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 15000
                    readTimeout = 15000
                }
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val data = JSONObject(body).getJSONObject("data")
                val newTimings = data.getJSONObject("timings")
                val meta = data.getJSONObject("meta")
                val city = meta.optString("timezone", "موقعك الحالي")
                runOnUiThread {
                    timings = newTimings
                    status.text = "الموقع: $city  •  طريقة الحساب: مصر"
                    renderTimings(newTimings)
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "فشل تحميل المواقيت. تأكد من الإنترنت وحاول مجددًا." }
            }
        }
    }

    private fun renderTimings(t: JSONObject) {
        timesBox.removeAllViews()
        prayers.forEachIndexed { i, name ->
            val raw = t.optString(keys[i], "--:--").substringBefore(" ")
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(8, 13, 8, 13)
            }
            row.addView(TextView(this).apply {
                text = name
                textSize = 17f
                setTextColor(white)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this).apply {
                text = raw
                textSize = 18f
                setTextColor(gold)
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            })
            timesBox.addView(row)
            if (i != prayers.lastIndex) {
                timesBox.addView(View(this).apply { setBackgroundColor(Color.rgb(43, 77, 65)) },
                    LinearLayout.LayoutParams(-1, 1))
            }
        }
        updateNextPrayer(t)
    }

    private fun updateNextPrayer(t: JSONObject) {
        try {
            val fmt = SimpleDateFormat("HH:mm", Locale.US)
            val now = Calendar.getInstance()
            val current = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
            val upcoming = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
                .mapNotNull { key ->
                    val value = t.optString(key).substringBefore(" ")
                    val parsed = fmt.parse(value) ?: return@mapNotNull null
                    val c = Calendar.getInstance().apply { time = parsed }
                    Triple(key, c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE), value)
                }.firstOrNull { it.second > current }
            val item = upcoming ?: Triple("Fajr", -1, t.optString("Fajr"))
            val arabic = mapOf("Fajr" to "الفجر", "Dhuhr" to "الظهر", "Asr" to "العصر", "Maghrib" to "المغرب", "Isha" to "العشاء")
            nextPrayer.text = "${arabic[item.first]}  •  ${item.third}"
        } catch (_: Exception) {
            nextPrayer.text = "تم تحميل المواقيت"
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 22 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) requestLocationAndLoad()
        else status.text = "لازم تسمح بالموقع عشان نحدد مواقيت مدينتك تلقائيًا."
    }
}
